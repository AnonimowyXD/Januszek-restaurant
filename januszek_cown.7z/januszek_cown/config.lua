

Config = {}

Config.Kawiarnia = {

    {

        name = 'Kawiarnia',

        coords = vector3(-644.36, 248.65, 80.3),

        job = 'all',

        sprite  = 484,

		display = 4,

		scale   = 1.2,

		colour  = 1,

    }

}

Config.BurgerShot = {

    {

        name = 'BurgerShot',

        coords = vector3(-1194.3346, -891.861, 13.0),

        job = 'all',

        sprite  = 484,

		display = 4,

		scale   = 1.2,

		colour  = 1,

    }

}

Config.Tacos = {

    {

        name = 'Taco',

        coords = vector3(11.1878, -1606.078, 28.4),

        job = 'all',

        sprite  = 484,

		display = 4,

		scale   = 1.2,

		colour  = 1,

    }

}

Config.wloska = {

    {

        name = 'wloska',

        coords = vector3(129.346, -1052.8715, 22.0),

        job = 'all',

        sprite  = 484,

		display = 4,

		scale   = 1.2,

		colour  = 1,

    }

}



