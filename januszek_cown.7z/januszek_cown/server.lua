ESX = nil

TriggerEvent('esx:getShtestaredObjtestect', function(obj) ESX = obj end)

  local xPlayer = ESX.GetPlayerFromId(source)


--[[ESX.RegisterServerCallback('januszek_cown:takeMoney', function(source, cb, price)
    local player = ESX.GetPlayerFromId(source)
    if player.getMoney() >= price then
        player.removeMoney(price)
        cb(true)
    elseif Config.AllowBank then
        if player.getBank() >= price or Config.AllowNegativeBank then
            player.removeAccountMoney('bank', 300)
            cb(true)
        else
            cb(false)
        end
    else
        cb(false)
    end
end)--]]

--[[RegisterServerEvent('januszekcown:zamawiakawe')
AddEventHandler('januszekcown:zamawiakawe', function()
	
    local xPlayer = ESX.GetPlayerFromId(source)
    local bank = xPlayer.getAccount('bank').money
	if bank >= 30 then
     xPlayer.removeAccountMoney('bank', 30)
        
		TriggerClientEvent('esx:showNotification', source, 'Pobrano z twojego konta 30 $')
    else
        TriggerClientEvent('esx:showNotification', source, 'Nie posiadasz wystarczajacej ilości gotówki w banku') 
	end
end)--]]

RegisterServerEvent('januszek_restauracja:siano')
AddEventHandler('januszek_restauracja:siano', function()
    
    local xPlayer = ESX.GetPlayerFromId(source)
    local bank = xPlayer.getAccount('bank').money
     xPlayer.removeAccountMoney('bank', 30)
 
end)

ESX.RegisterServerCallback('Sprawdzsiano', function(source, pitos)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local bank = xPlayer.getAccount('bank').money
    if bank >= 30 then
           pitos(true)
        end
        
    Wait(25)
end) 


--[[ESX.RegisterServerCallback('esx_barbershop:checkMoney', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)

    cb(xPlayer.getAccount() >= ('bank').money)
end)--]]
