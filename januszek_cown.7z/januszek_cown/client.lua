local Keys = {

    ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
  
    ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
  
    ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  
    ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  
    ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  
    ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
  
    ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  
    ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
  
    ["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
  
  }
  
  ESX = nil
  
  local PlayerData = {}
  
  local start = false
  
  local currentDrugTask = {
  
      pointIndex = 0
  
  
  
  }
  
  isHidingRun = false
  
  local haveMilk = false
  
  local haveMilkLimit = false
  
  local busy = false
  
  ESX = nil
  
  
  
  Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getShtestaredObjtestect', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(100)
    end

    PlayerData = ESX.GetPlayerData()

end)
  
  RegisterNetEvent('esx:setJob')
  
  AddEventHandler('esx:setJob', function(job)
  
      PlayerData.job = job
  
  end)
  
  
  
  
  
  RegisterNetEvent('mrp_cows:stressPlayer')
  
  AddEventHandler('mrp_cows:stressPlayer', function()
  
      -- restore hunger & thirst
  
      TriggerEvent('esx_status:set', 'stress', 0)
  
  

  end)

  
  Citizen.CreateThread(function()
  
       for k, v in pairs(Config.Kawiarnia) do
  
          local marker = {
  
              name = v.name,
  
              type = 23,
  
              coords = v.coords,
  
              colour = { r = 255, b = 144, g = 208 },
  
              size = vector3(1.5, 1.5, 1.5),
  
              msg = 'Naciśnij ~INPUT_CONTEXT~ aby zakupić kawe.',
  
              action = BuyCoffee,
  
              shouldDraw = function()
  
                   return v.job == 'all' and not kawa
  
              end
  
          }
  
          TriggerEvent('disc-base:registerMarker', marker)
  
      end
end)

  
  local ready
  
  
  
function BuyCoffee()



        ESX.TriggerServerCallback('Sprawdzsiano', function(pitos)
      
      if pitos == true then
  
  
  
      kawa = true
  
       local playerPed = PlayerPedId()
  
       ready = false
  
   --    exports.pNotify:SendNotification({ text = '<center><font color=orange>Zamówiłeś kawę. Odczekaj chwilę.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
  --     ESX.ShowNotification('Zamówiłeś kawę. Odczekaj chwilę.')
    --   TriggerEvent('pNotify:SendNotification', {text = 'Zamówiłeś kawę. Odczekaj chwilę.'})
       TriggerEvent('pNotify:SendNotification', {text = '<center>Zamówiłeś <font color=orange>kawę <font color=white>odczekaj kilka <font color=orange>minut <font color=white>aby odebrać swoje zamówienie</center>'})
       TriggerEvent('pNotify:SendNotification', {text = '<center>Pobrano z konta <font color=green> 30 $</center>'})
       TriggerServerEvent('januszek_restauracja:siano') 
       else
       TriggerEvent('pNotify:SendNotification', {text = '<center><font color=red>Nie masz tyle siana</center>'})
     
       end
       end)
end
  
  
  
  
  
   Citizen.CreateThread(function()
  
   while true do
  
      Citizen.Wait(7)
  
      local ped = PlayerPedId()
  
      local coords = GetEntityCoords(ped)
  
      if kawa == true then
  
          if Vdist(-644.36, 248.65, 80.3, coords.x, coords.y, coords.z) < 5 then
  
          if ready == false then
  
              DrawText3D(-644.36, 248.65, 81.6, '~o~OCZEKIWANIE...')
  
          else
  
              DrawText3D(-644.36, 248.65, 81.6, '~g~ZAMÓWIENIE GOTOWE DO ODBIORU.')
  
                  if Vdist(-644.36, 248.65, 80.3, coords.x, coords.y, coords.z) < 2 then
  
                  ESX.ShowHelpNotification('Naciśnij ~INPUT_PICKUP~ aby odebrać zamówienie')
  
              if IsControlPressed(0, 38) then
  
                  kawa = false

                  DrinkCoffee()
  
              end
  
              end
  
          end
  
      end
  
      end
  
   end
  
   end)
  
  
  
    Citizen.CreateThread(function()
  
   while true do
  
      Citizen.Wait(1000)
  
      local ped = PlayerPedId()
  
      local coords = GetEntityCoords(ped)
  
      if ready == false then
  
          Citizen.Wait(30000)
  
          ready = true
  
          --  exports.pNotify:SendNotification({ text = '<center><font color=orange>Twoje zamówienie jest gotowe do odbioru.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
           --     ESX.ShowNotification('Twoje zamówienie jest gotowe do odbioru.')
                    TriggerEvent('pNotify:SendNotification', {text = 'Twoje zamówienie jest gotowe do odbioru.'})
                        TriggerEvent('pNotify:SendNotification', {text = '<center>Naciśnij <font color=orange>[E] <font color=white>aby napić się kawy lub <font color=orange>[BACKSPACE] <font color=white>aby odłyżć kubek</center>', timeout = 8000})
           --         exports.pNotify:SendNotification({ text = '<center><font color=orange>Naciśnij [E] aby napić się kawy lub [BACKSPACE] aby odłyżć resztki</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
  
      end
  
   end
  
   end)
  
  
  
  
  
  
  
  
  
      function DrawText3D(x,y,z, text)
  
      local onScreen,_x,_y=World3dToScreen2d(x,y,z)
  
      local px,py,pz=table.unpack(GetGameplayCamCoords())
  
      local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
  
  
  
      local scale = (1/dist)*2
  
      local fov = (1/GetGameplayCamFov())*100
  
      local scale = scale*fov*1.2
  
  
  
      if onScreen then
  
          SetTextScale(0.0*scale, 0.55*scale)
  
          SetTextFont(4)
  
          SetTextProportional(1)
  
          SetTextColour(255, 255, 255, 255)
  
          SetTextOutline()
  
          SetTextEntry("STRING")
  
          SetTextCentre(1)
  
          AddTextComponentString(text)
  
          World3dToScreen2d(x,y,z, 0) --Added Here return v.job == 'all' and not kawa
  
          DrawText(_x,_y)
  
      end
  
  end
  
  
  
  function Drinking()
  
      local ped = PlayerPedId()
  
  if IsEntityPlayingAnim(ped, "amb@world_human_drinking@coffee@male@base", "base", 3) or IsEntityPlayingAnim(ped, "amb@world_human_drinking@coffee@male@idle_a", "idle_c", 3) then
  
  return true
  
  end
  
  end
  
  
  
  function DrinkCoffee()
  
      prop_name = prop_name or 'p_amb_coffeecup_01' ---used cigarett prop for now. Tired of trying to place object.
  
      local ped = PlayerPedId()
  
      local x,y,z = table.unpack(GetEntityCoords(ped, true))
  
      local x,y,z = table.unpack(GetEntityCoords(ped))
  
      local prop = CreateObject(GetHashKey(prop_name), x, y, z + 0.2, true, true, true)
  
      local boneIndex = GetPedBoneIndex(ped, 28422)
  
              
  
      if not IsEntityPlayingAnim(ped, "amb@world_human_drinking@coffee@male@base", "base", 3) then
  
          RequestAnimDict("amb@world_human_drinking@coffee@male@base")
  
          while not HasAnimDictLoaded("amb@world_human_drinking@coffee@male@base") do
  
              Citizen.Wait(100)
  
          end
  
  
  
          RequestAnimDict("amb@world_human_drinking@coffee@male@idle_a")
  
          while not HasAnimDictLoaded("amb@world_human_drinking@coffee@male@idle_a") do
  
              Citizen.Wait(100)
  
          end
  
  
  
          Wait(100)
  
          AttachEntityToEntity(prop, ped, boneIndex, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
  
          TaskPlayAnim(ped, 'amb@world_human_drinking@coffee@male@base', 'base', 8.0, 8.0, -1, 49, 0, 0, 0, 0)
  
          Wait(2000)
  
          while IsEntityAttached(prop) do
  
              Wait(1)
  
           --  ESX.ShowHelpNotification('Naciśnij ~INPUT_FRONTEND_RRIGHT~ aby skończyć pić \n Naciśnij ~INPUT_PICKUP~ aby się napić')
  
              if IsControlPressed(0, 177)  then

                TriggerEvent("route68_progbar:client:progress", {
                    name = "odkładanie",
                    duration = 5000,
                    label = "Odkładanie kubka po kawie",
                    useWhileDead = true,
                    canCancel = false,
                    controlDisables = {
                        disableMovement = true,
                        disableCarMovement = true,
                        disableMouse = false,
                        disableCombat = true,
                     },
                     animation = {
                     },
                     prop = {
                     },
                     propTwo = {
                     },
                  })
  
                  Citizen.Wait(5000)--5 secondes
  
                  ClearPedSecondaryTask(ped)
  
                  DeleteObject(prop)
  
                  DeleteObject(prop)
  
           --       exports.pNotify:SendNotification({ text = '<center><font color=orange>Twój stres został zmniejszony.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
           --       ESX.ShowNotification('Twój stres został zmniejszony.')
                  TriggerEvent('pNotify:SendNotification', {text = 'Twój stres został zmniejszony.'})
                  
                  
  
             --     TriggerServerEvent('removeStress')
             --     TriggerEvent('esx_status:remove', 'stress', 20000000)
  
                  break
  
              end
  
               if IsControlJustReleased(0, 38) then

                TriggerEvent("route68_progbar:client:progress", {
                    name = "odkładanie2",
                    duration = 10000,
                    label = "Picie kawy",
                    useWhileDead = true,
                    canCancel = false,
                    controlDisables = {
                        disableMovement = true,
                        disableCarMovement = true,
                        disableMouse = false,
                        disableCombat = true,
                     },
                     animation = {
                     },
                     prop = {
                     },
                     propTwo = {
                     },
                  })

                TriggerEvent('esx_status:remove', 'stress', 20000)
                TriggerEvent('esx_status:add', 'thirst', 200000)
  
                  TaskPlayAnim(ped, 'amb@world_human_drinking@coffee@male@idle_a', 'idle_a', 8.0, 8.0, -1, 49, 4.0, 0, 0, 0)
  
                  Citizen.Wait(10000)
  
  
  
                  TaskPlayAnim(ped, 'amb@world_human_drinking@coffee@male@base', 'base', 8.0, 8.0, -1, 49, 0, 0, 0, 0)
  
              end
  
  
  
          end
  
      end
  
  end
  
  
  
  function drawNotification(Notification)
  
      SetNotificationTextEntry('STRING')
  
      AddTextComponentString(Notification)
  
      DrawNotification(false, false)
  
  end
  
  
  
  LoadDict = function(Dict)
  
      while not HasAnimDictLoaded(Dict) do 
  
          Wait(0)
  
          RequestAnimDict(Dict)
  
      end
  
  end
  
  
  
  
  
--[[  Citizen.CreateThread(function()
  
      while true do
  
          Citizen.Wait(0)
  
  for k, v in pairs(Config['PoleDance']['Locations']) do
  
                      if #(GetEntityCoords(PlayerPedId()) - v['Position']) <= 1.0 then
  
                          DrawText3D(v['Position'].x, v['Position'].y, v['Position'].z , '[E] Pole Dance')
  
                          if IsControlJustReleased(0, 51) then
  
                              LoadDict('mini@strip_club@pole_dance@pole_dance' .. v['Number'])
  
                              local scene = NetworkCreateSynchronisedScene(v['Position'], vector3(0.0, 0.0, 0.0), 2, false, false, 1065353216, 0, 1.3)
  
                              NetworkAddPedToSynchronisedScene(PlayerPedId(), scene, 'mini@strip_club@pole_dance@pole_dance' .. v['Number'], 'pd_dance_0' .. v['Number'], 1.5, -4.0, 1, 1, 1148846080, 0)
  
                              NetworkStartSynchronisedScene(scene)
  
                          end
  
                          if IsControlJustReleased(0, 177) then
  
                               ClearPedTasks(PlayerPedId())
  
                           end
  
                      end
  
                  end
  
              end
  
          end)--]]

  Citizen.CreateThread(function()
  
  
  
          local blip = AddBlipForCoord(vector3(-44.3913, -1679.983, 29.4216))
  
  
  
          SetBlipSprite (blip, 326)
  
          SetBlipDisplay(blip, 2)
  
          SetBlipScale  (blip, 0.7)
  
          SetBlipColour (blip, 32)
  
  
  
          BeginTextCommandSetBlipName('STRING')
  
          AddTextComponentString("Mosley's Auto Shop")
  
          EndTextCommandSetBlipName(blip)
  
          SetBlipAsShortRange(blip, true)
  
  
  
  end)
  
  
  
--[[  Citizen.CreateThread(function()
  
  
  
          local blip = AddBlipForCoord(vector3( -633.2703, 234.05424, 81.881))
  
  
  
          SetBlipSprite (blip, 133)
  
          SetBlipDisplay(blip, 2)
  
          SetBlipScale  (blip, 0.7)
  
          SetBlipColour (blip, 10)
  
  
  
          BeginTextCommandSetBlipName('STRING')
  
          AddTextComponentString('Bean Machine Coffee')
  
          EndTextCommandSetBlipName(blip)
  
          SetBlipAsShortRange(blip, true)
  
  
  
  end)--]]

--- JANUSZEK STRESS + STRZELANIE

Citizen.CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local status = IsPedShooting(ped)
        local silenced = IsPedCurrentWeaponSilenced(ped)

        if status and not silenced then
            TriggerEvent('esx_status:add', 'stress', 20000)
            Citizen.Wait(2000)
        else
            Citizen.Wait(1)
        end
    end
end)


  -----------------------BURGER SHOT-----------------------------------

  Citizen.CreateThread(function()
  
    for k, v in pairs(Config.BurgerShot) do

       local marker = {

           name = v.name,

           type = 23,

           coords = v.coords,

           colour = { r = 255, b = 144, g = 208 },

           size = vector3(1.5, 1.5, 1.5),

           msg = 'Naciśnij ~INPUT_CONTEXT~ aby zakupić burgera.',

           action = BuyBurger,

           shouldDraw = function()

                return v.job == 'all' and not burger

           end

       }

       TriggerEvent('disc-base:registerMarker', marker)

   end
end)


local ready



function BuyBurger()

   burger = true

    local playerPed = PlayerPedId()

    ready = false

--    exports.pNotify:SendNotification({ text = '<center><font color=orange>Zamówiłeś kawę. Odczekaj chwilę.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
--     ESX.ShowNotification('Zamówiłeś kawę. Odczekaj chwilę.')
  --  TriggerEvent('pNotify:SendNotification', {text = 'Zamówiłeś burgera. Odczekaj chwilę.'})
    TriggerEvent('pNotify:SendNotification', {text = '<center>Zamówiłeś <font color=orange>burgera <font color=white>odczekaj kilka <font color=orange>minut <font color=white>aby odebrać swoje zamówienie</center>'})
    TriggerServerEvent('januszekcown:zamawiakawe')

 end





Citizen.CreateThread(function()

while true do

   Citizen.Wait(7)

   local ped = PlayerPedId()

   local coords = GetEntityCoords(ped)

   if burger == true then

       if Vdist(-1194.3346, -891.861, 13.0, coords.x, coords.y, coords.z) < 5 then

       if ready == false then

           DrawText3D(-1194.3346, -891.861, 14.0453, '~o~OCZEKIWANIE...')

       else

           DrawText3D(-1194.3346, -891.861, 14.0453, '~g~ZAMÓWIENIE GOTOWE DO ODBIORU.')

               if Vdist(-1194.3346, -891.861, 13.0, coords.x, coords.y, coords.z) < 2 then

               ESX.ShowHelpNotification('Naciśnij ~INPUT_PICKUP~ aby odebrać zamówienie')

           if IsControlPressed(0, 38) then

               burger = false

               EatBurger()

           end

           end

       end

   end

   end

end

end)



 Citizen.CreateThread(function()

while true do

   Citizen.Wait(1000)

   local ped = PlayerPedId()

   local coords = GetEntityCoords(ped)

   if ready == false then

       Citizen.Wait(30000)

       ready = true

       --  exports.pNotify:SendNotification({ text = '<center><font color=orange>Twoje zamówienie jest gotowe do odbioru.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
        --     ESX.ShowNotification('Twoje zamówienie jest gotowe do odbioru.')
                 TriggerEvent('pNotify:SendNotification', {text = 'Twoje zamówienie jest gotowe do odbioru.'})
                 TriggerEvent('pNotify:SendNotification', {text = '<center>Naciśnij <font color=orange>[E] <font color=white>aby zjeść burgera lub <font color=orange>[BACKSPACE] <font color=white>aby odłyżć resztki</center>', timeout = 8000})

   end

end

end)









   function DrawText3D(x,y,z, text)

   local onScreen,_x,_y=World3dToScreen2d(x,y,z)

   local px,py,pz=table.unpack(GetGameplayCamCoords())

   local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)



   local scale = (1/dist)*2

   local fov = (1/GetGameplayCamFov())*100

   local scale = scale*fov*1.2



   if onScreen then

       SetTextScale(0.0*scale, 0.55*scale)

       SetTextFont(4)

       SetTextProportional(1)

       SetTextColour(255, 255, 255, 255)

       SetTextOutline()

       SetTextEntry("STRING")

       SetTextCentre(1)

       AddTextComponentString(text)

       World3dToScreen2d(x,y,z, 0) --Added Here return v.job == 'all' and not burger

       DrawText(_x,_y)

   end

end



function Eating()

   local ped = PlayerPedId()

if IsEntityPlayingAnim(ped, "amb@world_human_drinking@coffee@male@base", "static", 3) or IsEntityPlayingAnim(ped, "amb@world_human_drinking@coffee@male@idle_a", "idle_c", 3) then

return true

end

end



function EatBurger()

   prop_name2 = prop_name2 or 'prop_cs_burger_01' ---used cigarett prop for now. Tired of trying to place object.

   local ped = PlayerPedId()

   local x,y,z = table.unpack(GetEntityCoords(ped, true))

   local x,y,z = table.unpack(GetEntityCoords(ped))

   local prop = CreateObject(GetHashKey(prop_name2), x, y, z + 0.2, true, true, true)

   local boneIndex = GetPedBoneIndex(ped, 28422)

           

   if not IsEntityPlayingAnim(ped, "amb@code_human_wander_eating_donut@male@base", "base", 3) then

       RequestAnimDict("amb@code_human_wander_eating_donut@male@base")

       while not HasAnimDictLoaded("amb@code_human_wander_eating_donut@male@base") do

           Citizen.Wait(100)

       end



       RequestAnimDict("amb@code_human_wander_eating_donut@male@idle_a")

       while not HasAnimDictLoaded("amb@code_human_wander_eating_donut@male@idle_a") do

           Citizen.Wait(100)

       end



       Wait(100)

       AttachEntityToEntity(prop, ped, boneIndex, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)

       TaskPlayAnim(ped, 'amb@code_human_wander_eating_donut@male@base', 'static', 8.0, 8.0, -1, 49, 0, 0, 0, 0)

       Wait(2000)

       while IsEntityAttached(prop) do

           Wait(1)

      --    ESX.ShowHelpNotification('Naciśnij ~INPUT_FRONTEND_RRIGHT~ aby skończyć jeść \n Naciśnij ~INPUT_PICKUP~ aby zjeść')

           if IsControlPressed(0, 177)  then

            TriggerEvent("route68_progbar:client:progress", {
                name = "odkładanie",
                duration = 5000,
                label = "Odkładanie resztek burgera",
                useWhileDead = true,
                canCancel = false,
                controlDisables = {
                    disableMovement = true,
                    disableCarMovement = true,
                    disableMouse = false,
                    disableCombat = true,
                 },
                 animation = {
                 },
                 prop = {
                 },
                 propTwo = {
                 },
              })

               Citizen.Wait(5000)--5 secondes

               ClearPedSecondaryTask(ped)

               DeleteObject(prop)

               DeleteObject(prop)

        --       exports.pNotify:SendNotification({ text = '<center><font color=orange>Twój stres został zmniejszony.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
        --       ESX.ShowNotification('Twój stres został zmniejszony.')
               TriggerEvent('pNotify:SendNotification', {text = 'Twój stres został zmniejszony.'})
               
               

          --     TriggerServerEvent('removeStress')
          --     TriggerEvent('esx_status:remove', 'stress', 20000000)

               break

           end

            if IsControlJustReleased(0, 38) then

                TriggerEvent("route68_progbar:client:progress", {
                    name = "odkładanie2",
                    duration = 10000,
                    label = "jedzenie burgera",
                    useWhileDead = true,
                    canCancel = false,
                    controlDisables = {
                        disableMovement = true,
                        disableCarMovement = true,
                        disableMouse = false,
                        disableCombat = true,
                     },
                     animation = {
                     },
                     prop = {
                     },
                     propTwo = {
                     },
                  })

             TriggerEvent('esx_status:remove', 'stress', 20000)
             TriggerEvent('esx_status:add', 'hunger', 200000)

               TaskPlayAnim(ped, 'amb@code_human_wander_eating_donut@male@idle_a', 'idle_a', 8.0, 8.0, -1, 49, 4.0, 0, 0, 0)

               Citizen.Wait(10000)



               TaskPlayAnim(ped, 'amb@code_human_wander_eating_donut@male@base', 'static', 8.0, 8.0, -1, 49, 0, 0, 0, 0)

           end



       end

   end

end



function drawNotification(Notification)

   SetNotificationTextEntry('STRING')

   AddTextComponentString(Notification)

   DrawNotification(false, false)

end



LoadDict = function(Dict)

   while not HasAnimDictLoaded(Dict) do 

       Wait(0)

       RequestAnimDict(Dict)

   end

end





       --------------------------TACO------------------

  
       Citizen.CreateThread(function()
  
        for k, v in pairs(Config.Tacos) do
    
           local marker = {
    
               name = v.name,
    
               type = 23,
    
               coords = v.coords,
    
               colour = { r = 255, b = 144, g = 208 },
    
               size = vector3(1.5, 1.5, 1.5),
    
               msg = 'Naciśnij ~INPUT_CONTEXT~ aby zakupić Taco.',
    
               action = BuyTaco,
    
               shouldDraw = function()
    
                    return v.job == 'all' and not taco
    
               end
    
           }
    
           TriggerEvent('disc-base:registerMarker', marker)
    
       end
    end)
    
    
    local ready
    
    
    
    function BuyTaco()
    
       taco = true
    
        local playerPed = PlayerPedId()
    
        ready = false
    
    --    exports.pNotify:SendNotification({ text = '<center><font color=orange>Zamówiłeś kawę. Odczekaj chwilę.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
    --     ESX.ShowNotification('Zamówiłeś kawę. Odczekaj chwilę.')
  --    TriggerEvent('pNotify:SendNotification', {text = 'Zamówiłeś Taco. Odczekaj chwilę.'})
        TriggerEvent('pNotify:SendNotification', {text = '<center>Zamówiłeś <font color=orange>taco <font color=white>odczekaj kilka <font color=orange>minut <font color=white>aby odebrać swoje zamówienie</center>'})
        TriggerServerEvent('januszekcown:zamawiakawe')
    
     end
    
    
    
    
    
    Citizen.CreateThread(function()
    
    while true do
    
       Citizen.Wait(7)
    
       local ped = PlayerPedId()
    
       local coords = GetEntityCoords(ped)
    
       if taco == true then
    
           if Vdist(11.1878, -1606.078, 28.4, coords.x, coords.y, coords.z) < 5 then
    
           if ready == false then
    
               DrawText3D(11.1878, -1606.078, 29.444, '~o~OCZEKIWANIE...')
    
           else
    
               DrawText3D(11.1878, -1606.078, 29.444, '~g~ZAMÓWIENIE GOTOWE DO ODBIORU.')
    
                   if Vdist(11.1878, -1606.078, 28.4, coords.x, coords.y, coords.z) < 2 then
    
                   ESX.ShowHelpNotification('Naciśnij ~INPUT_PICKUP~ aby odebrać zamówienie')
    
               if IsControlPressed(0, 38) then
    
                   taco = false
    
                   EatTaco()
    
               end
    
               end
    
           end
    
       end
    
       end
    
    end
    
    end)
    
    
    
     Citizen.CreateThread(function()
    
    while true do
    
       Citizen.Wait(1000)
    
       local ped = PlayerPedId()
    
       local coords = GetEntityCoords(ped)
    
       if ready == false then
    
           Citizen.Wait(30000)
    
           ready = true
    
           --  exports.pNotify:SendNotification({ text = '<center><font color=orange>Twoje zamówienie jest gotowe do odbioru.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
            --     ESX.ShowNotification('Twoje zamówienie jest gotowe do odbioru.')
                     TriggerEvent('pNotify:SendNotification', {text = 'Twoje zamówienie jest gotowe do odbioru.'})
                        TriggerEvent('pNotify:SendNotification', {text = '<center>Naciśnij <font color=orange>[E] <font color=white>aby zjeść tacosa lub <font color=orange>[BACKSPACE] <font color=white>aby odłyżć resztki</center>', timeout = 8000})
    
       end
    
    end
    
    end)
    
    
    
    
    
    
    
    
    
       function DrawText3D(x,y,z, text)
    
       local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    
       local px,py,pz=table.unpack(GetGameplayCamCoords())
    
       local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
    
    
    
       local scale = (1/dist)*2
    
       local fov = (1/GetGameplayCamFov())*100
    
       local scale = scale*fov*1.2
    
    
    
       if onScreen then
    
           SetTextScale(0.0*scale, 0.55*scale)
    
           SetTextFont(4)
    
           SetTextProportional(1)
    
           SetTextColour(255, 255, 255, 255)
    
           SetTextOutline()
    
           SetTextEntry("STRING")
    
           SetTextCentre(1)
    
           AddTextComponentString(text)
    
           World3dToScreen2d(x,y,z, 0) --Added Here return v.job == 'all' and not taco
    
           DrawText(_x,_y)
    
       end
    
    end
    
    
    
    function EatingTaco()
    
       local ped = PlayerPedId()
    
    if IsEntityPlayingAnim(ped, "amb@code_human_wander_eating_donut@male@base", "static", 3) or IsEntityPlayingAnim(ped, "amb@world_human_drinking@coffee@male@idle_a", "idle_c", 3) then
    
    return true
    
    end
    
    end
    
    
    
    function EatTaco()
    
       prop_name3 = prop_name3 or 'prop_taco_02' ---used cigarett prop for now. Tired of trying to place object.
    
       local ped = PlayerPedId()
    
       local x,y,z = table.unpack(GetEntityCoords(ped, true))
    
       local x,y,z = table.unpack(GetEntityCoords(ped))
    
       local prop = CreateObject(GetHashKey(prop_name3), x, y, z + 0.2, true, true, true)
    
       local boneIndex = GetPedBoneIndex(ped, 28422)
    
               
    
       if not IsEntityPlayingAnim(ped, "amb@code_human_wander_eating_donut@male@base", "static", 3) then
    
           RequestAnimDict("amb@code_human_wander_eating_donut@male@base")
    
           while not HasAnimDictLoaded("amb@code_human_wander_eating_donut@male@base") do
    
               Citizen.Wait(100)
    
           end
    
    
    
           RequestAnimDict("amb@code_human_wander_eating_donut@male@idle_a")
    
           while not HasAnimDictLoaded("amb@code_human_wander_eating_donut@male@idle_a") do
    
               Citizen.Wait(100)
    
           end
    
    
    
           Wait(100)
    
           AttachEntityToEntity(prop, ped, boneIndex, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    
           TaskPlayAnim(ped, 'amb@code_human_wander_eating_donut@male@base', 'static', 8.0, 8.0, -1, 49, 0, 0, 0, 0)
    
           Wait(2000)
    
           while IsEntityAttached(prop) do
    
               Wait(1)
    
    --          ESX.ShowHelpNotification('Naciśnij ~INPUT_FRONTEND_RRIGHT~ aby skończyć jeść \n Naciśnij ~INPUT_PICKUP~ aby zjeść')
    
               if IsControlPressed(0, 177)  then

                TriggerEvent("route68_progbar:client:progress", {
                    name = "odkładanie",
                    duration = 5000,
                    label = "Odkładanie resztek tacosa",
                    useWhileDead = true,
                    canCancel = false,
                    controlDisables = {
                        disableMovement = true,
                        disableCarMovement = true,
                        disableMouse = false,
                        disableCombat = true,
                     },
                     animation = {
                     },
                     prop = {
                     },
                     propTwo = {
                     },
                  })
    
                   Citizen.Wait(5000)--5 secondes
    
                   ClearPedSecondaryTask(ped)
    
                   DeleteObject(prop)
    
                   DeleteObject(prop)
    
            --       exports.pNotify:SendNotification({ text = '<center><font color=orange>Twój stres został zmniejszony.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
            --       ESX.ShowNotification('Twój stres został zmniejszony.')
                   TriggerEvent('pNotify:SendNotification', {text = 'Twój stres został zmniejszony.'})
                   
                   
    
              --     TriggerServerEvent('removeStress')
              --     TriggerEvent('esx_status:remove', 'stress', 20000000)
    
                   break
    
               end
    
                if IsControlJustReleased(0, 38) then

                    TriggerEvent("route68_progbar:client:progress", {
                        name = "odkładanie2",
                        duration = 10000,
                        label = "Jedzenie tacosa",
                        useWhileDead = true,
                        canCancel = false,
                        controlDisables = {
                            disableMovement = true,
                            disableCarMovement = true,
                            disableMouse = false,
                            disableCombat = true,
                         },
                         animation = {
                         },
                         prop = {
                         },
                         propTwo = {
                         },
                      })
    
                 TriggerEvent('esx_status:remove', 'stress', 20000)
                 TriggerEvent('esx_status:add', 'hunger', 200000)
    
                   TaskPlayAnim(ped, 'amb@code_human_wander_eating_donut@male@idle_a', 'idle_a', 8.0, 8.0, -1, 49, 4.0, 0, 0, 0)
    
                   Citizen.Wait(10000)
    
    
    
                   TaskPlayAnim(ped, 'amb@code_human_wander_eating_donut@male@base', 'static', 8.0, 8.0, -1, 49, 0, 0, 0, 0)
    
               end
    
    
    
           end
    
       end
    
    end
    
    
    
    function drawNotification(Notification)
    
       SetNotificationTextEntry('STRING')
    
       AddTextComponentString(Notification)
    
       DrawNotification(false, false)
    
    end
    
    
    
    LoadDict = function(Dict)
    
       while not HasAnimDictLoaded(Dict) do 
    
           Wait(0)
    
           RequestAnimDict(Dict)
    
       end
    
    end
  

    -----------------------wloska RESTAURACJA----------------


    Citizen.CreateThread(function()
  
        for k, v in pairs(Config.wloska) do
    
           local marker = {
    
               name = v.name,
    
               type = 23,
    
               coords = v.coords,
    
               colour = { r = 255, b = 144, g = 208 },
    
               size = vector3(1.5, 1.5, 1.5),
    
               msg = 'Naciśnij ~INPUT_CONTEXT~ aby zakupić wino.',
    
               action = BuyWino,
    
               shouldDraw = function()
    
                    return v.job == 'all' and not wino
    
               end
    
           }
    
           TriggerEvent('disc-base:registerMarker', marker)
    
       end
    end)
    
    
    local ready
    
    
    
    function BuyWino()
    
       wino = true
    
        local playerPed = PlayerPedId()
    
        ready = false
    
    --    exports.pNotify:SendNotification({ text = '<center><font color=orange>Zamówiłeś kawę. Odczekaj chwilę.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
    --     ESX.ShowNotification('Zamówiłeś kawę. Odczekaj chwilę.')
    --    TriggerEvent('pNotify:SendNotification', {text = 'Zamówiłeś wino. Odczekaj chwilę.'})
        TriggerEvent('pNotify:SendNotification', {text = '<center>Zamówiłeś <font color=orange>wino <font color=white>odczekaj kilka <font color=orange>minut <font color=white>aby odebrać swoje zamówienie</center>'})
        TriggerServerEvent('januszekcown:zamawiakawe')
    
     end
    
    
    
    
    
    Citizen.CreateThread(function()
    
    while true do
    
       Citizen.Wait(7)
    
       local ped = PlayerPedId()
    
       local coords = GetEntityCoords(ped)
    
       if wino == true then
    
           if Vdist(129.346, -1052.8715, 22.0, coords.x, coords.y, coords.z) < 5 then
    
           if ready == false then
    
               DrawText3D(129.346, -1052.8715, 23.0102, '~o~OCZEKIWANIE...')
    
           else
    
               DrawText3D(129.346, -1052.8715, 23.0102, '~g~ZAMÓWIENIE GOTOWE DO ODBIORU.')
    
                   if Vdist(129.346, -1052.8715, 22.0, coords.x, coords.y, coords.z) < 2 then
    
                   ESX.ShowHelpNotification('Naciśnij ~INPUT_PICKUP~ aby odebrać zamówienie')
    
               if IsControlPressed(0, 38) then
    
                   wino = false
    
                   DrinkWino()
    
               end
    
               end
    
           end
    
       end
    
       end
    
    end
    
    end)
    
    
    
     Citizen.CreateThread(function()
    
    while true do
    
       Citizen.Wait(1000)
    
       local ped = PlayerPedId()
    
       local coords = GetEntityCoords(ped)
    
       if ready == false then
    
           Citizen.Wait(30000)
    
           ready = true
    
           --  exports.pNotify:SendNotification({ text = '<center><font color=orange>Twoje zamówienie jest gotowe do odbioru.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
            --     ESX.ShowNotification('Twoje zamówienie jest gotowe do odbioru.')
                     TriggerEvent('pNotify:SendNotification', {text = 'Twoje zamówienie jest gotowe do odbioru.'})
                        TriggerEvent('pNotify:SendNotification', {text = '<center>Naciśnij <font color=orange>[E] <font color=white>aby napić się lampki wina lub <font color=orange>[BACKSPACE] <font color=white>aby odłyżć resztki</center>', timeout = 8000})
    
       end
    
    end
    
    end)
    
    
    
    
    
    
    
    
    
       function DrawText3D(x,y,z, text)
    
       local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    
       local px,py,pz=table.unpack(GetGameplayCamCoords())
    
       local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
    
    
    
       local scale = (1/dist)*2
    
       local fov = (1/GetGameplayCamFov())*100
    
       local scale = scale*fov*1.2
    
    
    
       if onScreen then
    
           SetTextScale(0.0*scale, 0.55*scale)
    
           SetTextFont(4)
    
           SetTextProportional(1)
    
           SetTextColour(255, 255, 255, 255)
    
           SetTextOutline()
    
           SetTextEntry("STRING")
    
           SetTextCentre(1)
    
           AddTextComponentString(text)
    
           World3dToScreen2d(x,y,z, 0) --Added Here return v.job == 'all' and not burger
    
           DrawText(_x,_y)
    
       end
    
    end
    
    
    
    function DrinkingWino()
    
       local ped = PlayerPedId()
    
    if IsEntityPlayingAnim(ped, "amb@code_human_wander_drinking_fat@male@base", "static", 3) then
    
    return true
    
    end
    
    end
    
    
    
    function DrinkWino()
    
       prop_name4 = prop_name4 or 'prop_drink_redwine' ---used cigarett prop for now. Tired of trying to place object.
    
       local ped = PlayerPedId()
    
       local x,y,z = table.unpack(GetEntityCoords(ped, true))
    
       local x,y,z = table.unpack(GetEntityCoords(ped))
    
       local prop = CreateObject(GetHashKey(prop_name4), x, y, z + 0.2, true, true, true)
    
       local boneIndex = GetPedBoneIndex(ped, 28422)
    
               
    
       if not IsEntityPlayingAnim(ped, "amb@code_human_wander_drinking_fat@male@base", "static", 3) then
    
           RequestAnimDict("amb@code_human_wander_drinking_fat@male@base")
    
           while not HasAnimDictLoaded("amb@code_human_wander_drinking_fat@male@base") do
    
               Citizen.Wait(100)
    
           end
    
    
    
           RequestAnimDict("amb@world_human_drinking@coffee@male@idle_a")
    
           while not HasAnimDictLoaded("amb@world_human_drinking@coffee@male@idle_a") do
    
               Citizen.Wait(100)
    
           end
    
    
    
           Wait(100)
    
           AttachEntityToEntity(prop, ped, boneIndex, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    
           TaskPlayAnim(ped, 'amb@code_human_wander_drinking_fat@male@base', 'static', 8.0, 8.0, -1, 49, 0, 0, 0, 0)
    
           Wait(2000)
    
           while IsEntityAttached(prop) do
    
               Wait(1)
    
       --       ESX.ShowHelpNotification('Naciśnij ~INPUT_FRONTEND_RRIGHT~ aby skończyć jeść \n Naciśnij ~INPUT_PICKUP~ aby zjeść')
    
               if IsControlPressed(0, 177)  then

                TriggerEvent("route68_progbar:client:progress", {
                    name = "odkładanie",
                    duration = 5000,
                    label = "Odkładanie lampki wina",
                    useWhileDead = true,
                    canCancel = false,
                    controlDisables = {
                        disableMovement = true,
                        disableCarMovement = true,
                        disableMouse = false,
                        disableCombat = true,
                     },
                     animation = {
                     },
                     prop = {
                     },
                     propTwo = {
                     },
                  })
    
                   Citizen.Wait(5000)--5 secondes
    
                   ClearPedSecondaryTask(ped)
    
                   DeleteObject(prop)
    
                   DeleteObject(prop)
    
            --       exports.pNotify:SendNotification({ text = '<center><font color=orange>Twój stres został zmniejszony.</center>', queue = "top", timeout = 5500, layout = "centerLeft" })
            --       ESX.ShowNotification('Twój stres został zmniejszony.')
                   TriggerEvent('pNotify:SendNotification', {text = 'Twój stres został zmniejszony.'})
                   
                   
    
              --     TriggerServerEvent('removeStress')
              --     TriggerEvent('esx_status:remove', 'stress', 20000000)
    
                   break
    
               end
    
                if IsControlJustReleased(0, 38) then

                    TriggerEvent("route68_progbar:client:progress", {
                        name = "odkładanie2",
                        duration = 10000,
                        label = "Picie lampki wina",
                        useWhileDead = true,
                        canCancel = false,
                        controlDisables = {
                            disableMovement = true,
                            disableCarMovement = true,
                            disableMouse = false,
                            disableCombat = true,
                         },
                         animation = {
                         },
                         prop = {
                         },
                         propTwo = {
                         },
                      })
    
                 TriggerEvent('esx_status:remove', 'stress', 20000)
                 TriggerEvent('esx_status:add', 'drunk', 200000)
    
                   TaskPlayAnim(ped, 'amb@world_human_drinking@coffee@male@idle_a', 'idle_a', 8.0, 8.0, -1, 49, 4.0, 0, 0, 0)
    
                   Citizen.Wait(10000)
    
    
    
                   TaskPlayAnim(ped, 'amb@code_human_wander_drinking_fat@male@base', 'static', 8.0, 8.0, -1, 49, 0, 0, 0, 0)
    
               end
    
    
    
           end
    
       end
    
    end
    
    
    
    function drawNotification(Notification)
    
       SetNotificationTextEntry('STRING')
    
       AddTextComponentString(Notification)
    
       DrawNotification(false, false)
    
    end
    
    
    
    LoadDict = function(Dict)
    
       while not HasAnimDictLoaded(Dict) do 
    
           Wait(0)
    
           RequestAnimDict(Dict)
    
       end
    
    end